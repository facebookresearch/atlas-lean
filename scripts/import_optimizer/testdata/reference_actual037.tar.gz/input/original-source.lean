/-
# Optimal worst-case estimators for signal reconstruction
-/
module

public import Mathlib

@[expose] public section

namespace OpenConjectures.Analysis.owr11695855003OpenProblem

/-! Source record `OWR-11695855-003__30005250`. -/

/-!
# Optimal worst-case estimators for signal reconstruction

The source ([OWR-11695855-003], Mini-Workshop: Mathematical Foundations
of Robust and Generalizable Learning (2023), Oberwolfach Reports, DOI
10.4171/owr/2022/46, pp. 2659--2686) asks *when* three properties hold
for worst-case signal-reconstruction estimators:

1. a minimax-optimal continuous estimator exists for the worst-case
   squared-error risk over a signal model `S` and a bounded noise ball;
2. the robust (worst-case) value equals a regularized expected-risk
   value for some Tikhonov weight `lam` with `0 < lam` (the recorded
   source scope requires a strictly positive weight);
3. risk order under an in-distribution measure `P` is preserved under
   a translated measure `Q`.

None of these is asserted here: asserted unconditionally, (3) is false
already for `E = ℝ` with Dirac measures (review counterexample), so this
entry is a classification interface exposing the three properties as
predicates over the data, with risks valued in `ENNReal` so that infinite
and non-integrable risks are represented faithfully (the Bochner
integral would silently return `0` on non-integrable functions, and a
real-valued supremum cannot represent `+∞`). The open content — the
additional conditions under which each property holds — is not
formalized; see `formalization.gaps`.
-/

variable (E : Type*) [NormedAddCommGroup E]
  [InnerProductSpace ℝ E] [CompleteSpace E] [MeasurableSpace E] [BorelSpace E]

/-- Worst-case squared-error risk of a continuous estimator `f` over the
signal model `S` and the noise ball of radius `ε`, valued in `ENNReal` so
unbounded risks are `+∞` rather than a conditionally complete real
supremum. -/
noncomputable def worstRisk (S : Set E) (ε : ℝ)
    (f : ContinuousMap E E) : ENNReal :=
  ⨆ x ∈ S, ⨆ w ∈ Metric.ball (0 : E) ε,
    ENNReal.ofReal (‖f (x + w) - x‖ ^ 2)

/-- Expected squared-error risk of `f` under the joint law `μ` on the
observation space `E × E`, whose first coordinate is the clean signal
`x` and whose second is the corrupted observation `y`. The loss is
`‖f y - x‖²`, so the estimator is compared with the clean signal it is
supposed to reconstruct, not with its own input (the identity
estimator therefore does not have zero risk unless the observation
equals the signal). Valued in `ENNReal` via the Lebesgue integral, so
non-integrable risks are `+∞` rather than the Bochner integral's
silent `0`. -/
noncomputable def expectedRisk (μ : MeasureTheory.ProbabilityMeasure (E × E))
    (f : ContinuousMap E E) : ENNReal :=
  MeasureTheory.lintegral (μ : MeasureTheory.Measure (E × E)) (fun p => ENNReal.ofReal (‖f p.2 - p.1‖ ^ 2))

/-- Property 1 of the source question: a minimax-optimal continuous
estimator exists for the worst-case risk. Exposed as a predicate; not
asserted. -/
def MinimaxOptimalExists (S : Set E) (ε : ℝ) : Prop :=
  ∃ f₀ : ContinuousMap E E,
    ∀ f : ContinuousMap E E, worstRisk E S ε f₀ ≤ worstRisk E S ε f

/-- Property 2 of the source question: for some Tikhonov weight
`lam` with `0 < lam` (the strictly positive weight required by the
recorded source scope), the robust value equals the regularized
expected-risk value. The regularizer is the Tikhonov term
`lam * ∫ ‖f y‖² dP`, a genuine estimator-output norm, not evaluation
at a single point. Exposed as a predicate; not asserted. -/
def RobustRegularizedEquivalence (S : Set E) (ε : ℝ)
    (P : MeasureTheory.ProbabilityMeasure (E × E)) : Prop :=
  ∃ lam : ℝ, 0 < lam ∧
    (⨅ f : ContinuousMap E E, worstRisk E S ε f) =
      ⨅ f : ContinuousMap E E,
        expectedRisk E P f + ENNReal.ofReal lam *
          MeasureTheory.lintegral ((P : MeasureTheory.Measure (E × E)).map Prod.snd) (fun y => ENNReal.ofReal (‖f y‖ ^ 2))

/-- Property 3 of the source question: risk order under the in-distribution
joint law `P` implies risk order under the translated joint law `Q`.
Exposed as a predicate; not asserted (it fails unconditionally, e.g.
for Dirac measures on `ℝ`). -/
def RiskOrderPreserved (P Q : MeasureTheory.ProbabilityMeasure (E × E)) : Prop :=
  ∀ f g : ContinuousMap E E,
    expectedRisk E P f ≤ expectedRisk E P g →
      expectedRisk E Q f ≤ expectedRisk E Q g

end OpenConjectures.Analysis.owr11695855003OpenProblem
